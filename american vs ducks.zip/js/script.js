window.onload = function() {
  const canvas = document.getElementById('myCanvas');
  const ctx = canvas.getContext('2d');

  // Billeder
  const playerImg = new Image();
  playerImg.src = './img/american.png';
  const duckImg = new Image();
  duckImg.src = './img/duck.png';
  const bulletImg = new Image();
  bulletImg.src = './img/shell.png';

  // Spilvariabler
  let playerX = 370;
  let playerY = 500;
  const playerSpeed = 7;

  let bullets = [];
  let ducks = [];
  let score = 0;
  let health = 3;

  let leftPressed = false;
  let rightPressed = false;
  let spacePressed = false;
  let canShoot = true;

  // Start med 3 ænder
  for (let i = 0; i < 3; i++) {
    ducks.push(makeDuck());
  }

  // Funktion til at lave en ny and
  function makeDuck() {
    return {
      x: Math.random() * 700,
      y: Math.random() * 150 + 20,
      speed: (Math.random() < 0.5 ? -1 : 1) * (2 + Math.random() * 2),
      alive: true,
      falling: false,
      scored: false // sikrer at man kun får point én gang
    };
  }

  // Input
  document.addEventListener("keydown", e => {
    if (e.key === "ArrowLeft") leftPressed = true;
    if (e.key === "ArrowRight") rightPressed = true;
    if (e.code === "Space") spacePressed = true;
  });

  document.addEventListener("keyup", e => {
    if (e.key === "ArrowLeft") leftPressed = false;
    if (e.key === "ArrowRight") rightPressed = false;
    if (e.code === "Space") spacePressed = false;
  });

  // Skyd med 0,5 sek forsinkelse
  function shoot() {
    if (spacePressed && canShoot) {
      bullets.push({ x: playerX + 25, y: playerY });
      canShoot = false;
      setTimeout(() => (canShoot = true), 500); // 0.5 sek delay
    }
  }

  // Opdater alt
  function update() {
    // Bevæg spiller
    if (leftPressed && playerX > 0) playerX -= playerSpeed;
    if (rightPressed && playerX < 740) playerX += playerSpeed;

    // Skydning
    shoot();

    // Opdater kugler
    for (let b of bullets) {
      b.y -= 8;
    }
    bullets = bullets.filter(b => b.y > 0);

    // Opdater ænder
    for (let d of ducks) {
      if (d.alive && !d.falling) {
        // Flyver frem og tilbage
        d.x += d.speed;
        if (d.x < 0 || d.x > 760) d.speed *= -1;
      } else if (d.falling) {
        d.y += 5;

        // Hvis den falder ud af banen
        if (d.y > 600) {
          d.alive = false;
          d.falling = false;
        }

        // Hvis den rammer spilleren
        if (
          d.y + 40 > playerY &&
          d.x < playerX + 50 &&
          d.x + 40 > playerX
        ) {
          health--;
          document.getElementById("health").textContent = health;
          // Erstat med ny and
          const index = ducks.indexOf(d);
          ducks[index] = makeDuck();
          if (health <= 0) gameOver();
        }
      }
    }

    // Kugle rammer and
    for (let b of bullets) {
      for (let d of ducks) {
        if (
          d.alive &&
          !d.falling &&
          b.x < d.x + 50 &&
          b.x + 10 > d.x &&
          b.y < d.y + 40 &&
          b.y + 10 > d.y
        ) {
          d.falling = true;
          d.alive = false;
          if (!d.scored) {
            score++;
            d.scored = true;
            document.getElementById("score").textContent = score;
          }
        }
      }
    }

    // Erstat døde ænder der er faldet ud
    for (let i = 0; i < ducks.length; i++) {
      if (!ducks[i].alive && !ducks[i].falling) {
        ducks[i] = makeDuck();
      }
    }
  }

  // Tegn alt
  function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    ctx.drawImage(playerImg, playerX, playerY, 60, 80);

    for (let b of bullets) {
      ctx.drawImage(bulletImg, b.x, b.y, 10, 20);
    }

    for (let d of ducks) {
      if (d.alive || d.falling) {
        ctx.drawImage(duckImg, d.x, d.y, 50, 40);
      }
    }
  }

  function gameOver() {
    alert("Du blev ramt! Game Over!");
    document.location.reload();
  }

  function gameLoop() {
    update();
    draw();
    requestAnimationFrame(gameLoop);
  }

  // Vent til billederne er klar
  let loadedImages = 0;
  const totalImages = 3;
  [playerImg, duckImg, bulletImg].forEach(img => {
    img.onload = () => {
      loadedImages++;
      if (loadedImages === totalImages) {
        gameLoop();
      }
    };
  });
};
